﻿<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once get_template_directory() . '/inc/theme-setup.php';
require_once get_template_directory() . '/inc/acf-fields.php';
require_once get_template_directory() . '/inc/rest-contact.php';
require_once get_template_directory() . '/inc/fallback-options.php';
